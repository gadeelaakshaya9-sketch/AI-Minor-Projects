# Unlocks Academy — Flask Mini Project 6
## Student Registration System

This project is based on the revised Google Colab notebook provided by the student.

### Features
- Student registration form
- GET routes for home, about, and student directory
- POST route for registration
- Server-side validation for name, email, age, course, and duplicate email
- Registration success page with generated student ID
- HTML templates and responsive CSS

### Routes
| Method | Route | Purpose |
|---|---|---|
| GET | `/` | Registration form |
| GET | `/about` | Project information |
| GET | `/students` | Registered students directory |
| POST | `/register` | Validate and register a student |

### Run in Google Colab
Open `Mini_Project_6_Colab.ipynb` in Google Colab and run all cells from top to bottom. The final cell starts Flask and asks Colab to create a temporary preview link.

### Run locally
Install dependencies with `pip install -r requirements.txt`, then run `python app.py` and visit `http://127.0.0.1:5000`.

### Limitations
This is a learning demo using in-memory storage. Registered records are lost when the app restarts. The demo secret key is not suitable for public deployment. Do not enter sensitive personal information.

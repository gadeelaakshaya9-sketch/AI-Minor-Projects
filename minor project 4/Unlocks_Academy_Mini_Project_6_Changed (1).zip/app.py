from flask import Flask, render_template, request, redirect, url_for, flash

app = Flask(__name__)
app.secret_key = "student-registration-demo-key"  # Demo only; do not use a real secret in public deployment.

# In-memory storage keeps this beginner project simple.
# Registered students reset when the app restarts.
students = []
next_id = 1

@app.route("/")
def index():
    """Display the registration form."""
    return render_template("index.html")

@app.route("/about")
def about():
    """Explain the purpose of the project."""
    return render_template("about.html")

@app.route("/students", methods=["GET"])
def list_students():
    """Display all students currently registered."""
    return render_template("students.html", students=students)

@app.route("/register", methods=["POST"])
def register():
    """Validate submitted data and register a student."""
    global next_id

    name = request.form.get("name", "").strip()
    email = request.form.get("email", "").strip().lower()
    course = request.form.get("course", "").strip()
    age_text = request.form.get("age", "").strip()

    errors = []
    if not name:
        errors.append("Please enter the student's name.")
    elif len(name) < 2:
        errors.append("Name must contain at least 2 characters.")

    if not email:
        errors.append("Please enter an email address.")
    elif "@" not in email or "." not in email.rsplit("@", 1)[-1]:
        errors.append("Please enter a valid email address.")

    if not course:
        errors.append("Please choose a course.")

    age = None
    if not age_text:
        errors.append("Please enter the student's age.")
    else:
        try:
            age = int(age_text)
            if age < 1 or age > 120:
                errors.append("Age must be between 1 and 120.")
        except ValueError:
            errors.append("Age must be a whole number.")

    if any(s["email"] == email for s in students):
        errors.append("This email address is already registered.")

    if errors:
        return render_template(
            "index.html", errors=errors,
            form_data={"name": name, "email": email, "age": age_text, "course": course}
        ), 400

    student = {
        "id": next_id,
        "name": name,
        "email": email,
        "age": age,
        "course": course
    }
    students.append(student)
    next_id += 1
    return render_template("result.html", student=student)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
